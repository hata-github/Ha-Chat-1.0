import pygame
import sys
pygame.init()
canvas = pygame.display.set_mode((60,60))
#请在下方书写你的代码
#播放语音
mp3name = sys.argv[1]
pygame.mixer.music.load(mp3name)
pygame.mixer.music.play()

while True:
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			exit()
	pygame.display.update()

