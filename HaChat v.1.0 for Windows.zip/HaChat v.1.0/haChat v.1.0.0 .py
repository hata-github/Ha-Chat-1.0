import tkinter as tk
from PIL import ImageTk
from aip import AipSpeech
import os
import easygui as e


window = tk.Tk()
window.geometry('1050x591')
window.resizable(0,0)
window.title('HaChat（v.1.0.0） By Bilibili 我的世界中的Windows7 https://space.bilibili.com/1198166444')   

def voice(): 
# 这个地方不能修改
# -----------------------------------分割线-----------------------------------
    appId = '24851802'
    apiKey = 'gmFwxHASuifsG7Kdla5Pjgjl'
    secretKey = 'xFf5ZSCdDwQGmc099UsFh9mBY3GIfy6C'
# -----------------------------------分割线-----------------------------------

    #请在下方书写你的代码
    #合成语音
# 这个地方不能修改
# -----------------------------------分割线-----------------------------------
    client = AipSpeech(appId,apiKey,secretKey)
    result = client.synthesis(content,'zh',1,{'vol':2,'per':0,'spd':4})
    mp3name = "voices/audio1.mp3"
    if not isinstance(result,dict):
        with open(mp3name,'wb') as f:
            f.write(result)
    #跳转文件
    os.system('python temp/voice.py %s' %mp3name)

bgImg = ImageTk.PhotoImage(file="images/bg.png")
bg = tk.Label(window,width=1050,height=591,image=bgImg)
bg.pack()

okImg = ImageTk.PhotoImage(file="images/ok.png")
#请在下方书写你的代码
#绑定函数
ok = tk.Button(window,width=135,height=43,image=okImg,bd=0,command=voice)
ok.place(x=455,y=540)

#请在下方书写你的代码
#显示多行文本
a = e.enterbox('你要说些什么呢？',title = 'HaChat')
if a == '你好':
     with open('text/01.txt','r',encoding = 'utf-8')as f:
         content = f.read()
elif a == 'github是什么？':
    with open('text/02.txt','r',encoding='utf-8') as f:
         content = f.read()
# elif a == '清平乐 村居':
#     with open('text/03.txt','r',encoding='utf-8') as f:
#         content = f.read()
# elif a == '芙蓉楼送辛渐':
#     with open('text/04.txt','r',encoding='utf-8') as f:
#         content = f.read()
# elif a == '塞下曲':
#     with open('text/05.txt','r',encoding='utf-8') as f:
#         content = f.read()
# elif a == '墨梅':
#     with open('text/06.txt','r',encoding='utf-8') as f:
#         content = f.read()


text = tk.Text(window,width=55,height=15,bg='#FFFFFF',font=("font/simhei.ttf",18))
text.place(x=190,y=115)
text.insert(tk.INSERT,content)

window.mainloop()
# -----------------------------------分割线-----------------------------------



